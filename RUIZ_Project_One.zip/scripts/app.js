const text = document.querySelector(".about-1");
const strText = text.textContent;

console.log(strText);
